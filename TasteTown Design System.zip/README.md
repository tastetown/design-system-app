# TasteTown Design System

A design system extracted from the **TasteTown** Figma file *"TasteTown · Old screeny.fig"* — an iOS-first mobile app in Czech that helps hungry people discover restaurants, cafés and bars near them, activate exclusive **DEALs** (buy-one-get-one burgers, free drinks, % off) and redeem them at the venue.

The product revolves around three bottom-nav destinations: **Profil** (your account + rewards), **Objevuj** (discover – a map and a list of nearby venues with their active deals) and **Moje dealy** (your active and redeemed deals). The core loop is: *browse map → pick a venue → activate a deal → show it to the waiter at the table → redeem it.*

The tone is **young, warm, a little cheeky** — the brand wants you to feel like a regular who got let in on a secret, not a coupon-clipper. The visual system is soft-modern iOS: rounded 18–22px cards, a hot orange-to-red gradient over subtle grain, generous whitespace, chunky rounded display type against a tight neutral UI sans.

---

## Sources

- **Figma file:** `TasteTown · Old screeny.fig` (mounted read-only into the project)
- **Pages** (all in-scope):
  - `/Taste-Town-komplet-ready-for-dev` — 98 frames, the "production" set
  - `/Taste-Town` — 16 frames, earlier polished variants
  - `/Taste-Town-sandbox` — 17 frames, exploration
  - `/HOT-NEW` — 1 frame
  - `/Logo` — 3 logo treatments

All screen labels and body copy are in Czech.

---

## Content fundamentals

**Language:** Czech. All UI copy, button labels and error states are Czech. Do not auto-translate; it reads as localised-first.

**Voice:** second-person singular, informal ("ty" form) — the app *du*'s you. It feels like a friend giving a tip, not a brand talking to a customer. Punctuation is light, exclamation marks are rare, emoji are used sparingly inside category pills ("🍔 Burgery", "🥗 Vegan", "☕️ Kavárna") but almost never in microcopy.

**Casing:**
- Screen titles: Sentence case, often bold display ("Telefonní číslo", "Vítej v TasteTown", "Voucher je platný").
- Section labels above groups: ALL CAPS, tracked, small (`MŮJ TASTE TOWN`, `VÍCE INFORMACÍ`, `KATEGORIE`, `TADY NÁS NAJDEŠ`).
- Buttons: Sentence case (`Pokračovat`, `Aktivovat`, `Spustit tutoriál`, `Zavřít`).
- Tab bar: Sentence case (`Profil`, `Objevuj`, `Moje dealy`).
- The product name itself is styled two ways: the logo lockup renders it as two words ("Taste Town") but in body copy it appears as one word ("TasteTown").

**Word choices / lexicon:**
- `DEAL` — always uppercase when referring to a specific offer token ("Aktivovat DEAL", "Zrušit DEAL", "Moje DEALY"). A DEAL is the unit of value.
- `Objevuj` (Discover) as the primary verb for browsing.
- `Aktivovat` (Activate) / `Uplatnit` (Redeem) — two-step flow.
- `Pozvi přítele a získej Měsíc zdarma` — referral reward ("Invite a friend and get a Month free").
- Prices in **Kč** (Czech crown), distances in **km**, times in 24h (`9:00 - 20:00`).

**Examples from the file:**
- `Zadej telefonní číslo a obdržíš SMS pro registraci. Nemusíš si tak pamatovat své heslo` — informational copy under inputs: declarative, explains the *why*.
- `Až dorazíš do podniku, řekni, že jsi tady s TasteTown a objednej si. DEAL uplatníš před obsluhou až při placení.` — instructional copy on the deals screen: short sentences, you-voice, tells you exactly what to do at the table.
- `Souhlasím s marketingovým sdělením` / `Souhlasím s podmínkami užívání a GDPR` — standard Czech consent copy, direct, no filler.
- Status words are single-word chips: `Otevřeno` (open, green), `Zavřeno` (closed), `Aktivováno`, `Uplatněno`.

**What the voice is NOT:** no corporate jargon, no exclamation-stacked marketing shouting, no emoji-per-sentence, no AI "I'm here to help!" tone. Think cool local app, not startup launch deck.

---

## Visual foundations

### Color

A tight palette built around **two anchor pairs**: a hot orange→red gradient for action, and a near-black ink on near-white paper for everything structural. A single green carries success and open-for-business status.

- **Brand orange** `rgb(255, 80, 0)` — primary action, deal pills, active tab, map pin fill
- **Brand orange deep** `rgb(249, 87, 48)` / `rgb(237, 51, 50)` — gradient stops, pressed state
- **Brand orange amber** `rgb(255, 111, 0)` / `rgb(255, 184, 0)` — gradient midtones, rating stars
- **Ink** `rgb(41, 42, 45)` — primary text, logo mark body, dark chips
- **Paper** `rgb(251, 251, 254)` — app background, card fill
- **Pure white** `rgb(255, 255, 255)` — elevated surfaces, button text
- **Muted** `rgb(140, 148, 166)` — secondary text, inactive tab labels
- **Hairline** `rgb(212, 215, 222)` — borders, dividers, inactive strokes
- **Surface-2** `rgb(242, 244, 249)` / `rgb(237, 238, 244)` — input fill, icon-button fill, field backgrounds
- **Success green** `rgb(15, 204, 91)` — "Lze uplatnit" (redeemable) banner, "Měsíc zdarma" reward card, `Otevřeno` text
- **Success green deep** `rgb(27, 182, 33)` — darker green used on text over solid green

The **hot gradient** is the single most recognisable thing after the logo: it runs from `rgb(237,51,50)` → `rgb(249,100,40)` → `rgb(249,87,48)` → `rgb(250,73,57)` with subtle noise grain over it. It wraps the entire viewport on discovery surfaces (the list of restaurants) so the UI feels *hot, warm, food*.

**Deal pill tint** is `rgba(255,80,0,0.12)` — a 12% wash of brand orange, with text in full orange. This is the single most-repeated component on the whole file.

### Typography

Two families do all the work:

- **Baloo Bhaijaan 2 / Baloo Bhaina 2**, ExtraBold (800) — display and headlines. Rounded, chunky, friendly, extremely on-brand. Sizes: 32, 28, 26, 22, 20, 17. Used for: screen titles, restaurant names, the logo wordmark, the "Měsíc zdarma" reward, the big 790 Kč savings number.
- **Inter**, Medium (500) / SemiBold (600) / Bold (700) / ExtraBold (800) / Black (900) — UI sans. Sizes: 11, 12, 13, 14, 15, 16, 17, 18, 20, 30, 40, 56. Used for: body copy, labels, buttons, metadata, deal pill text, the 40px money numbers.
- **SF Pro Text** Semibold 17 — only for the iOS status-bar clock; treat it as OS chrome, not a brand font.
- **Menlo** Regular 26 — shows up only in a tokenised SMS-code input.

The pairing is **rounded display + neutral UI** — it's the same playbook as modern food-delivery apps (Wolt, Glovo) but tipped warmer via the chunky Baloo.

### Spacing, radii, elevation

- **Radius scale:** 8 (chips, small pills), 12 (inputs, secondary buttons), 18 (content cards, restaurant cards), 22 (large deal pills, full-width primary buttons), 36 (the phone frame / full-screen modal sheet), 999 / circle (avatars, icon buttons, home indicator).
- **Spacing:** 4, 6, 8, 10, 12, 14, 16 (primary content margin), 24, 32. The canonical horizontal content margin is **16px** off each edge of the 375px phone frame → 343px content width.
- **Card pattern:** `rgb(251,251,254)` fill, `0.5px solid rgb(212,215,222)` border, subtle inset `0 0 0 2px white` and a 1px bottom line — the net effect is a slightly embossed paper card that sits warmly on the gradient.
- **Shadow system (on-canvas / below modal):** very soft, layered, cool-bluish — e.g. `0 2.7px 2.2px rgba(0,0,0,.048), 0 6.6px 5.3px rgba(0,0,0,.069), 0 12.5px 10px rgba(0,0,0,.085), 0 22.3px 17.9px rgba(0,0,0,.101), 0 41.8px 33.4px rgba(0,0,0,.122), 0 100px 80px rgba(0,0,0,.17)`. You'll see this most obviously on the phone frame itself and on the primary CTA button.
- **Colored shadow:** `rgba(113,166,229,0.16)` / `0.32` — a faint cool-blue cast used under primary cards to lift them off the warm background without muddying.

### Backgrounds

Two distinct background treatments:

1. **Paper** — the default. `rgb(251,251,254)` flat, used on profile, inputs, settings, SMS screens.
2. **Hot gradient + grain** — the discovery surface. A radial/linear red-orange gradient overlaid with a soft noise PNG (`assets/bg-texture-grain.png`). Restaurant cards float on top of this, giving the list a "warm plated tablecloth" feel.

Maps have their own treatment: a custom-styled Google/Mapbox-like map with muted fills, red "Praha" labels, and TasteTown orange pin markers.

### Motion & states

The file is static Figma; we infer from iOS conventions and component variants:

- **Hover/press on buttons:** no web-style color shift; instead the gradient CTA likely depresses slightly with a softer shadow. Secondary buttons press to the 12%-tint shade (press into their own outline).
- **Toggle switches:** pure iOS UIKit-style — green when on, grey track when off, with a white thumb.
- **Transitions:** assumed to be iOS-native push/modal (slide-up sheets from below, push-left between tabs).
- **No loading skeletons** visible in the file; real empty states use a centered illustration + short copy + CTA.

### Iconography

See the dedicated **Iconography** section below.

### Imagery

Food photography: warm, slightly saturated, natural daylight, shot against **soft neutral backdrops** (olive, cream, beige). Each restaurant card has one square food image. No people, no plates cluttered with logos, no stock-photo sheen — it reads as "someone's instagram, but well-lit." The hero on the venue detail page is full-bleed, 4:3, with a floating back button and heart.

### Components & layout rules

- **Tab bar:** 3 items, fixed bottom, `rgb(251,251,254)` surface with a soft top shadow, active item is orange glyph + orange label, inactive is muted grey.
- **Primary CTA:** full-width, 22px radius, gradient orange→red fill, white 15px Inter SemiBold label, often with a small icon at the right.
- **Secondary CTA:** same geometry, white fill, hairline border, ink label.
- **Deal pill:** 22px radius capsule, `rgba(255,80,0,0.12)` fill, orange Inter-Bold 14px text, 12px horizontal padding. These come in rows and overflow the card — you see them truncated with clipping, never wrapped.
- **Input:** 12px radius, grey `rgb(237,238,244)` fill when empty, 1.5px orange outline when focused, 15px Inter Medium text.
- **Status chip:** text-only, inline, colored (green "Otevřeno" / red "Zavřeno").

---

## Iconography

TasteTown uses **custom-drawn outline glyphs** for navigation and a **small set of category emojis** for food-type pills. There is no off-the-shelf icon font (no SF Symbols badging, no Material Icons, no Lucide). Every Figma icon is hand-exported as an SVG in the source file (e.g. `Search-Glyph.svg`, `Chevron.svg`, `Vector.svg`, `Touch-ID-Symbol.svg`).

**Style rules:**
- 24×24 nominal grid, most glyphs drawn at ~18×18 inside that.
- Filled style for primary actions (tab-bar glyphs when active, map pin, heart when favourited).
- Outline style, 1.5–2px stroke, for inactive/secondary (tab-bar when inactive, chevrons, search, filter).
- Color is `rgb(41,42,45)` ink or `rgb(140,148,166)` muted, or brand orange when active.
- No duotone, no rounded-square backplates — glyphs sit directly on the surface or inside a circular `rgb(237,238,244)` chip (the map top bar pattern).

**Emoji usage** is limited and consistent:
- `🍔` Burgery, `🥐` Snídaně, `🥗` Vegan, `☕️` Kavárna, `🇨🇿` language toggle, `🔥` referral heat.
- Used only inside category tiles / labels, never in body copy, button labels, or toasts.

**Unicode characters as visual dividers:** the bullet `・` (Japanese interpunct) is used between metadata items on restaurant cards (`Burgery ・ Nápoje ・ Fast food`). `|` pipes separate rating / distance / status (`4.3 | 0.4 km | Otevřeno`).

**Flag:** no CDN icon library is currently linked. This system substitutes **Lucide** (`https://unpkg.com/lucide@latest`) — MIT-licensed, matching 1.5–2px outline stroke weight — wherever we need an icon we haven't explicitly exported from Figma. *Flagged substitution: ideally the team's own SVG set replaces Lucide 1-for-1. Please provide the final icon set when available.*

---

## Font substitution

The Figma calls for **Baloo Bhaijaan 2 ExtraBold** (and the likely-misnamed duplicate **Baloo Bhaina 2 ExtraBold** — the same family, different weight picker). Both are freely available on Google Fonts as `Baloo Bhaijaan 2`. **Inter** is also Google Fonts. We load both from Google Fonts CDN in `colors_and_type.css` — no local `.ttf` files shipped (the Figma binary doesn't contain them either). *No substitution needed; if you have internally-licensed TTFs, drop them into `fonts/` and they will take precedence.*

`SF Pro Text` and `Menlo` are Apple system fonts used purely in iOS status-bar chrome and a code-input specimen — not brand fonts. We don't load them; the OS provides them.

---

## Repository index

```
/
├─ index.html                  ← main entry / table of contents
├─ README.md
├─ SKILL.md
│
├─ tokens/
│   ├─ colors-and-type.css     ← single source of truth
│   └─ icons.css               ← icon mask sprite
│
├─ fonts/                      ← brand TTFs (Baloo, Inter)
│
├─ assets/
│   ├─ brand/                  ← logo, app icon, pin, texture
│   ├─ food/                   ← food photography
│   └─ maps/                   ← map tiles
│
├─ components/                 ← atomic components (one HTML per concept)
│   └─ … (colors, type, buttons, inputs, cards, tabbar, …)
│
├─ screens/                    ← compositions — full screens built from components
│   ├─ 01-discover-map.html
│   └─ screens-print.html
│
└─ _archive/                   ← raw Figma exports + scrap PNGs (not part of system)
```

**Linking convention:** components reference tokens with `../tokens/`, screens reference components/tokens/assets with `../...`. The index links to everything with relative paths.
